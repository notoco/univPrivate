This is a dependency add-on for plexkodiconnect
